package com.example.mvc.Entity;

import lombok.Data;

import java.util.ArrayList;

@Data
public class Document {
    private int id;

    private String content;
}